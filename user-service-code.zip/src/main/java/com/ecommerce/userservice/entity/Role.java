package com.ecommerce.userservice.entity;

    public enum Role {

        ADMIN,
        CUSTOMER,
        BUSINESS
    }

